package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.lti.model.Student;
import com.lti.util.JpaUtil;

public class StudentDaoImpl implements StudentDao {
	private EntityManager entityManager;
	
	public StudentDaoImpl() {
		entityManager = JpaUtil.getEntityManager();
	}

	@Override
	public int insertStudent(Student student) {
		entityManager.persist(student);
		return 1;
	}

	@Override
	public int deleteStudent(int id) {
		Student stu = entityManager.find(Student.class, id);
		entityManager.remove(stu);
		System.out.println(stu);
		return 1;
	}

	@Override
	public Student readStudent(int id) {
		return entityManager.find(Student.class, id);
	}

	
	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
		
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	@Override
	public void rollbackTransaction() {
		entityManager.getTransaction().rollback();
		
	}

	@Override
	public int updateStudent(Student student) {
		entityManager.merge(student);
		return 1;
	}

	@Override
	public List<Student> displayStudent() {
		TypedQuery<Student> tquery=entityManager.createQuery("From Student",Student.class);
		List<Student> list2=tquery.getResultList();

		return list2;
		
	}

}
