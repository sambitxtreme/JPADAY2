package com.lti.util;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

public class JpaUtil {
	private static EntityManager entityManager;
	
	public static EntityManager getEntityManager() {
		if(entityManager == null)
			entityManager = Persistence.createEntityManagerFactory("JPA_PU").createEntityManager();
		
		return entityManager;
	}
}
