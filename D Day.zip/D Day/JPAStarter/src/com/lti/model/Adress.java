package com.lti.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="address")
public class Adress {

	@Id
  private int adressId;
  private String city;
  private String pin;
  
  public Adress(){
	  
  }
public Adress(int adressId, String city, String pin) {
	super();
	this.adressId = adressId;
	this.city = city;
	this.pin = pin;
	
}
@Override
public String toString() {
	return "Adress [adressId=" + adressId + ", city=" + city + ", pin=" + pin + ", getAdressId()=" + getAdressId()
			+ ", getCity()=" + getCity() + ", getPin()=" + getPin() + ", getClass()=" + getClass() + ", hashCode()="
			+ hashCode() + ", toString()=" + super.toString() + "]";
}
public int getAdressId() {
	return adressId;
}
public void setAdressId(int adressId) {
	this.adressId = adressId;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getPin() {
	return pin;
}
public void setPin(String pin) {
	this.pin = pin;
}
}
